package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the BlockCheck property
 * </p>
 */
public enum BlockCheckConstants {
  /**
   * <p>
   * Constants used by the BlockCheck property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xBLOCKCHECK_SUM1, // 0
  /**
   * <p>
   * Constants used by the BlockCheck property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xBLOCKCHECK_SUM2, // 1
  /**
   * <p>
   * Constants used by the BlockCheck property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xBLOCKCHECK_CRC, // 2
}
