package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the RemoteKermit property
 * </p>
 */
public enum RemoteKermitConstants {
  /**
   * <p>
   * Constants used by the RemoteKermit property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xREMOTEKERMIT_INTERACTIVE, // 0
  /**
   * <p>
   * Constants used by the RemoteKermit property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xREMOTEKERMIT_SERVER, // 1
  /**
   * <p>
   * Constants used by the RemoteKermit property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xREMOTEKERMIT_EITHER, // 2
}
