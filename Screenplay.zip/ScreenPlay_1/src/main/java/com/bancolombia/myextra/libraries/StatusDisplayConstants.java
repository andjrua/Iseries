package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the StatusDisplay property
 * </p>
 */
public enum StatusDisplayConstants {
  /**
   * <p>
   * Constants used by the StatusDisplay property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xSTATUSNONE, // 0
  /**
   * <p>
   * Constants used by the StatusDisplay property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xSTATUSINDICATOR, // 1
  /**
   * <p>
   * Constants used by the StatusDisplay property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xSTATUSHOST, // 2
}
