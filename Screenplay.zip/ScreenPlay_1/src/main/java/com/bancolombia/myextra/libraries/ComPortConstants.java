package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the Port property
 * </p>
 */
public enum ComPortConstants {
  /**
   * <p>
   * Constants used by the Port property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xPORT_COM1, // 0
  /**
   * <p>
   * Constants used by the Port property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xPORT_COM2, // 1
  /**
   * <p>
   * Constants used by the Port property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xPORT_COM3, // 2
  /**
   * <p>
   * Constants used by the Port property
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  xPORT_COM4, // 3
}
