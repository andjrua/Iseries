package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * Provides access to the Operator Information Area
 */
@IID("{A3B414A0-D8B2-11CF-884D-08005AC0F29E}")
public interface OIA extends Com4jObject {
  // Methods:
  /**
   * <p>
   * Returns the contents of the OIA as a character string
   * </p>
   * <p>
   * Getter method for the COM property "Value"
   * </p>
   * @return  Returns a value of type java.lang.String
   */

  @DISPID(0) //= 0x0. The runtime will prefer the VTID if present
  @VTID(7)
  @DefaultMethod
  java.lang.String value();


  /**
   * <p>
   * Returns the System object
   * </p>
   * <p>
   * Getter method for the COM property "Application"
   * </p>
   * @return  Returns a value of type com4j.Com4jObject
   */

  @DISPID(1) //= 0x1. The runtime will prefer the VTID if present
  @VTID(8)
  @ReturnValue(type=NativeType.Dispatch)
  com4j.Com4jObject application();


  /**
   * <p>
   * Returns the parent of the object
   * </p>
   * <p>
   * Getter method for the COM property "Parent"
   * </p>
   * @return  Returns a value of type com4j.Com4jObject
   */

  @DISPID(2) //= 0x2. The runtime will prefer the VTID if present
  @VTID(9)
  @ReturnValue(type=NativeType.Dispatch)
  com4j.Com4jObject parent();


  /**
   * <p>
   * Returns whether or not the OIA has been updated since it was last accessed
   * </p>
   * <p>
   * Getter method for the COM property "Updated"
   * </p>
   * @return  Returns a value of type int
   */

  @DISPID(3) //= 0x3. The runtime will prefer the VTID if present
  @VTID(10)
  int updated();


  /**
   * <p>
   * Returns the status of the XCLOCK
   * </p>
   * <p>
   * Getter method for the COM property "XStatus"
   * </p>
   * @return  Returns a value of type short
   */

  @DISPID(4) //= 0x4. The runtime will prefer the VTID if present
  @VTID(11)
  short xStatus();


  /**
   * <p>
   * Returns the status of the host connection
   * </p>
   * <p>
   * Getter method for the COM property "ConnectionStatus"
   * </p>
   * @return  Returns a value of type short
   */

  @DISPID(5) //= 0x5. The runtime will prefer the VTID if present
  @VTID(12)
  short connectionStatus();


  /**
   * <p>
   * Returns any error status
   * </p>
   * <p>
   * Getter method for the COM property "ErrorStatus"
   * </p>
   * @return  Returns a value of type short
   */

  @DISPID(6) //= 0x6. The runtime will prefer the VTID if present
  @VTID(13)
  short errorStatus();


  // Properties:
}
