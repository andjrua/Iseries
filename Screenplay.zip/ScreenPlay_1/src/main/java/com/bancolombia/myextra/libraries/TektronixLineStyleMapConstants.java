package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the TektronixLineStyleMap property
 * </p>
 */
public enum TektronixLineStyleMapConstants {
  /**
   * <p>
   * Constants used by the TektronixLineStyleMap property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xTEKLINESTYLE, // 0
  /**
   * <p>
   * Constants used by the TektronixLineStyleMap property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xTEKLINECOLOR, // 1
  /**
   * <p>
   * Constants used by the TektronixLineStyleMap property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xTEKLINEBOTH, // 2
}
