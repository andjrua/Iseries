package co.com.bancolombia.screenplay.toolsqa.userinterface;

import org.openqa.selenium.By;

import net.serenitybdd.screenplay.targets.Target;

public class AccessoriesPage {

	
	public static final Target MAGIC_MOUSE = Target.the("magic mouse").
			located(By.linkText("Magic Mouse"));
}
