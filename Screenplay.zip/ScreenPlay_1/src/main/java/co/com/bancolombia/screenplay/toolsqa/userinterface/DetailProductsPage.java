package co.com.bancolombia.screenplay.toolsqa.userinterface;

import org.openqa.selenium.By;

import net.serenitybdd.screenplay.targets.Target;

public class DetailProductsPage {

	public static final Target ADD_TO_CAR = Target.the("button add to car ").
			located(By.name("Buy"));
	
	public static final Target COUNT = Target.the("get count of products").
			located(By.className("count"));
}
