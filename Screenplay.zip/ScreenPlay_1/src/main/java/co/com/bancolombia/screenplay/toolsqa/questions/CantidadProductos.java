package co.com.bancolombia.screenplay.toolsqa.questions;

import co.com.bancolombia.screenplay.toolsqa.userinterface.DetailProductsPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class CantidadProductos implements Question<String>{

	
	@Override
	public String answeredBy(Actor actor) {
		
		return DetailProductsPage.COUNT.resolveFor(actor).getText();
	}

	
	public static CantidadProductos quantityOfItemsFromCar () {
		
		return new CantidadProductos();
		
	}
	
}
