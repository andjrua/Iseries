package co.com.bancolombia.screenplay.toolsqa.userinterface;

import org.openqa.selenium.By;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;

public class MenuPage extends PageObject{

	public static final Target PRODUCT_CATEGORY = Target.the("opcion del menu categoria de productos")
			.located(By.linkText("Product Category"));
		
	public static final Target ACCESSORIES = Target.the("opcion accesorios dentro del menu")
			.located(By.linkText("Accessories"));
}
