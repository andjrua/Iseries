package co.com.bancolombia.screenplay.ejemplo.userinterfaces;

import com.bancolombia.myextra.objects.TargetMyExtra;

public class LoginPage {

	public static final TargetMyExtra USUARIO = TargetMyExtra.the("campo usuario").locatedBy(53, 6, 9);
	public static final TargetMyExtra CONTRASENA = TargetMyExtra.the("campo contrasena").locatedBy(53, 7, 9);
	
}
