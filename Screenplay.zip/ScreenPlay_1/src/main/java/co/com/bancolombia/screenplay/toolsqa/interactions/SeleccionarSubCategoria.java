package co.com.bancolombia.screenplay.toolsqa.interactions;

import org.openqa.selenium.By;

import co.com.bancolombia.screenplay.toolsqa.userinterface.MenuPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Hover;
import net.serenitybdd.screenplay.targets.Target;

public class SeleccionarSubCategoria implements Interaction {
	
	private String opcion;
	private String item;
	
	public SeleccionarSubCategoria(String opcion, String item) {
		this.opcion=opcion;
		this.item=item;
	}

	@Override
	public <T extends Actor> void performAs(T actor) {
		
		Target opcionPrincipal = Target.the("opcion del menu " + opcion)
				.located(By.linkText(opcion));
			
		Target itemASeleccionar = Target.the("opcion " + item + " dentro del menu")
				.located(By.linkText(item));
		
				actor.attemptsTo(Hover.over(opcionPrincipal),
				Click.on(itemASeleccionar));
	}
	
}
