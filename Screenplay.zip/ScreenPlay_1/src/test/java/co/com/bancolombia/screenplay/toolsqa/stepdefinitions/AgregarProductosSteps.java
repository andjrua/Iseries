package co.com.bancolombia.screenplay.toolsqa.stepdefinitions;

import cucumber.api.java.Before;
import cucumber.api.java.ast.Cuando;
import cucumber.api.java.es.Dado;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;

import static net.serenitybdd.screenplay.actors.OnStage.*;

import static org.hamcrest.core.Is.is;

import co.com.bancolombia.screenplay.toolsqa.tasks.AgregarAlCarritoDeCompras;
import co.com.bancolombia.screenplay.toolsqa.userinterface.HomeStorePage;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static co.com.bancolombia.screenplay.toolsqa.questions.CantidadProductos.quantityOfItemsFromCar;

public class AgregarProductosSteps {

	private HomeStorePage homeStorePage;
	
	@Before
	public void prepararEscenario() {
		OnStage.setTheStage(new OnlineCast());
		// la linea anterior me crea todos los actores, no los tengo que crear yo
		// solo me toca luego usar un metodo de serenity que devuelve un actor
	}
	
	
	@Cuando("^agrego el articulo (.*)$")
	public void agregoElArticulo(String mouse) throws Exception {
		theActorCalled("santiago").wasAbleTo(Open.browserOn(homeStorePage),AgregarAlCarritoDeCompras.elProducto(mouse));
		
	}

	@Entonces("^el articulo se debe observar en el carro de compras$")
	public void elArticuloSeDebeObservarEnElCarroDeCompras() throws Exception {
	
		theActorInTheSpotlight().should(seeThat(quantityOfItemsFromCar(),is("1")));
	}

	
	
}
