package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the TerminalType property
 * </p>
 */
public enum TerminalTypeConstants {
  /**
   * <p>
   * Constants used by the TerminalType property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xTERMINALTYPE_ALL, // 0
  /**
   * <p>
   * Constants used by the TerminalType property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xTERMINALTYPE_CURRENT, // 1
  /**
   * <p>
   * Constants used by the TerminalType property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xTERMINALTYPE_CUSTOM, // 2
}
