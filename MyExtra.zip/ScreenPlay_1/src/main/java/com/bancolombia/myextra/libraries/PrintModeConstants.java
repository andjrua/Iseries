package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the PrintMode property
 * </p>
 */
public enum PrintModeConstants {
  /**
   * <p>
   * Constants used by the PrintMode property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xPRINTMODENORMAL, // 0
  /**
   * <p>
   * Constants used by the PrintMode property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xPRINTMODEAUTO, // 1
  /**
   * <p>
   * Constants used by the PrintMode property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xPRINTMODECONTROLLER, // 2
}
