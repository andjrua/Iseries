package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the TimeBetweenRedials property
 * </p>
 */
public enum ModemRedialConstants {
  /**
   * <p>
   * Constants used by the TimeBetweenRedials property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xMODEMREDIAL10SECS, // 0
  /**
   * <p>
   * Constants used by the TimeBetweenRedials property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xMODEMREDIAL30SECS, // 1
  /**
   * <p>
   * Constants used by the TimeBetweenRedials property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xMODEMREDIAL1MIN, // 2
  /**
   * <p>
   * Constants used by the TimeBetweenRedials property
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  xMODEMREDIAL2MIN, // 3
}
