package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the SixelColorSpecification property
 * </p>
 */
public enum SixelColorSpecificationConstants {
  /**
   * <p>
   * Constants used by the SixelColorSpecification property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xCOLORHLS, // 0
  /**
   * <p>
   * Constants used by the SixelColorSpecification property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xCOLORRGB, // 1
}
