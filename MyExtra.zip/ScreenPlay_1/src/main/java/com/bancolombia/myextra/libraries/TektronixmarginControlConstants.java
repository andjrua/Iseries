package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the TektronixmarginControl property
 * </p>
 */
public enum TektronixmarginControlConstants {
  /**
   * <p>
   * Constants used by the TektronixmarginControl property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xTEKMARGINNONE, // 0
  /**
   * <p>
   * Constants used by the TektronixmarginControl property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xTEKMARGIN1, // 1
  /**
   * <p>
   * Constants used by the TektronixmarginControl property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xTEKMARGIN2, // 2
}
