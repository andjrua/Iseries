package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the PrintExtent property
 * </p>
 */
public enum PrintExtentConstants {
  /**
   * <p>
   * Constants used by the PrintExtent property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xPRINTEXTENTPAGE, // 0
  /**
   * <p>
   * Constants used by the PrintExtent property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xPRINTEXTENTREGION, // 1
  /**
   * <p>
   * Constants used by the PrintExtent property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xPRINTEXTENTSELECTION, // 2
  /**
   * <p>
   * Constants used by the PrintExtent property
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  xPRINTEXTENTALLPAGES, // 3
}
