package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the EditMode property
 * </p>
 */
public enum EditModeConstants {
  /**
   * <p>
   * Constants used by the EditMode property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xEDITMODEINTERACTIVE, // 0
  /**
   * <p>
   * Constants used by the EditMode property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xEDITMODEENABLED, // 1
  /**
   * <p>
   * Constants used by the EditMode property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xEDITMODEUNAVAILABLE, // 2
}
