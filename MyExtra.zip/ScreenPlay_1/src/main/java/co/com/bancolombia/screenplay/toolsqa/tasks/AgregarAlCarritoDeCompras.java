package co.com.bancolombia.screenplay.toolsqa.tasks;

import co.com.bancolombia.screenplay.toolsqa.interactions.SeleccionarOpcion;
import co.com.bancolombia.screenplay.toolsqa.userinterface.AccessoriesPage;
import co.com.bancolombia.screenplay.toolsqa.userinterface.DetailProductsPage;
import co.com.bancolombia.screenplay.toolsqa.userinterface.HomeStorePage;
import co.com.bancolombia.screenplay.toolsqa.userinterface.MenuPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Hover;

public class AgregarAlCarritoDeCompras implements Task {

	private String producto;
	
	public AgregarAlCarritoDeCompras(String producto) {
		this.producto = producto;
	}

	public static AgregarAlCarritoDeCompras elProducto(String producto) {
		return new AgregarAlCarritoDeCompras(producto);
	}

	
	@Override
	public <T extends Actor> void performAs(T actor) {
		actor.attemptsTo(
				SeleccionarOpcion.menuOpcion("Product Category").menuItem("Accessories"),
				Click.on(AccessoriesPage.MAGIC_MOUSE),
				Click.on(DetailProductsPage.ADD_TO_CAR));
		
	}

}
