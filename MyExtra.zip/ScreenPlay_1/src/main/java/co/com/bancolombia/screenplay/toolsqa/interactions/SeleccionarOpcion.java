package co.com.bancolombia.screenplay.toolsqa.interactions;


public class SeleccionarOpcion{

	private String opcion;
	
	public SeleccionarOpcion(String opcion) {
		this.opcion=opcion;
	}

	public static SeleccionarOpcion menuOpcion (String opcion) {
		return new SeleccionarOpcion(opcion);
	}
	
	public SeleccionarSubCategoria menuItem (String item) {
		return new SeleccionarSubCategoria(opcion, item);
		
	}


	

}
