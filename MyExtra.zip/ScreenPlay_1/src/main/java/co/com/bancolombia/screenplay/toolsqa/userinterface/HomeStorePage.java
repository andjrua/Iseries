package co.com.bancolombia.screenplay.toolsqa.userinterface;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;


@DefaultUrl ("http://store.demoqa.com")
public class HomeStorePage extends PageObject {


	
		
}
