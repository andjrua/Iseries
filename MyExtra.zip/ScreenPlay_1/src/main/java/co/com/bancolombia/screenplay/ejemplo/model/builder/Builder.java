package co.com.bancolombia.screenplay.ejemplo.model.builder;

public interface Builder <T> {
	
	T build();

}
