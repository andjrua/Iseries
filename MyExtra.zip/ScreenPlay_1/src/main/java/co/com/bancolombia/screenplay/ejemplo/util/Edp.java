package co.com.bancolombia.screenplay.ejemplo.util;

public enum Edp {
	CALIDAD("D:\\Documents\\Sesiones de AS400\\MAT.EDP");

	private String ruta;
	
	Edp(String ruta){
		this.ruta = ruta;
	}

	public String getRuta() {
		return ruta;
	}
		
}
