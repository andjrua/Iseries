package co.com.bancolombia.screenplay.ejemplo.userinterfaces;

import com.bancolombia.myextra.objects.TargetMyExtra;

public class LoginPage {

	public static final TargetMyExtra USUARIO = TargetMyExtra.the("campo usuario").locatedBy(06, 53, 9);
	public static final TargetMyExtra CONTRASENA = TargetMyExtra.the("campo contrasena").locatedBy(07, 53, 9);
		
}
