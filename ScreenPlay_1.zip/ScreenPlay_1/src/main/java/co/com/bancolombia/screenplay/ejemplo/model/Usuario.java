package co.com.bancolombia.screenplay.ejemplo.model;

public class Usuario {
	
	private final String usuario;
	private final String contrasena;
	
	public Usuario(String usuario, String contrasena) {
		this.usuario = usuario;
		this.contrasena = contrasena;
	}
	public String getUsuario() {
		return usuario;
	}
	public String getContrasena() {
		return contrasena;
	}
	
	

}
