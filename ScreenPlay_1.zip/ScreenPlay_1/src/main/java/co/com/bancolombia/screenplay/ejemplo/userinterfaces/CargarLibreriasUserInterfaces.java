package co.com.bancolombia.screenplay.ejemplo.userinterfaces;

import com.bancolombia.myextra.objects.TargetMyExtra;

public class CargarLibreriasUserInterfaces {

	public static final TargetMyExtra CARGARLIBRERIAS = TargetMyExtra.the("Campo para cargar librerias").locatedBy(8, 13, 10);
			
	
}
