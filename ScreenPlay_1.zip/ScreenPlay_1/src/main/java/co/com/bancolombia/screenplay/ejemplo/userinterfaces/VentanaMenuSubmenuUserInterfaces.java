package co.com.bancolombia.screenplay.ejemplo.userinterfaces;

import com.bancolombia.myextra.objects.TargetMyExtra;

public class VentanaMenuSubmenuUserInterfaces {

	public static final TargetMyExtra POSICION1 = TargetMyExtra.the("Posicion 1").locatedBy(18, 8, 1);
	public static final TargetMyExtra POSICION2 = TargetMyExtra.the("Posicion 2").locatedBy(19, 8, 1);
	public static final TargetMyExtra POSICION3 = TargetMyExtra.the("Posicion 3").locatedBy(20, 8, 1);
}
