package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the FunctionKey properties
 * </p>
 */
public enum FunctionKeyConstants {
  /**
   * <p>
   * Constants used by the FunctionKey properties
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xFKEYLOCALACTION, // 0
  /**
   * <p>
   * Constants used by the FunctionKey properties
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xFKEYFKEY, // 1
  /**
   * <p>
   * Constants used by the FunctionKey properties
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xFKEYIGNORE, // 2
}
