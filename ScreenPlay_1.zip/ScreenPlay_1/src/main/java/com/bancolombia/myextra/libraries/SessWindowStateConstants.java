package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the Session.WindowState property
 * </p>
 */
public enum SessWindowStateConstants {
  /**
   * <p>
   * Constants used by the Session.WindowState property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xMINIMIZED, // 0
  /**
   * <p>
   * Constants used by the Session.WindowState property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xNORMAL, // 1
  /**
   * <p>
   * Constants used by the Session.WindowState property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xMAXIMIZED, // 2
}
