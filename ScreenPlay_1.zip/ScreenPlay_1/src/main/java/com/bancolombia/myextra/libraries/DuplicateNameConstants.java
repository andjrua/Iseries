package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the DuplicateName property
 * </p>
 */
public enum DuplicateNameConstants {
  /**
   * <p>
   * Constants used by the DuplicateName property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xDUPFILEPROMPT, // 0
  /**
   * <p>
   * Constants used by the DuplicateName property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xDUPFILERENAME, // 1
  /**
   * <p>
   * Constants used by the DuplicateName property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xDUPFILERENAMEOLD, // 2
  /**
   * <p>
   * Constants used by the DuplicateName property
   * </p>
   * <p>
   * The value of this constant is 3
   * </p>
   */
  xDUPFILEOVERWRITE, // 3
  /**
   * <p>
   * Constants used by the DuplicateName property
   * </p>
   * <p>
   * The value of this constant is 4
   * </p>
   */
  xDUPFILEDISCARD, // 4
  /**
   * <p>
   * Constants used by the DuplicateName property
   * </p>
   * <p>
   * The value of this constant is 5
   * </p>
   */
  xDUPFILEAPPEND, // 5
}
