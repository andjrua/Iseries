package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the DataBits property
 * </p>
 */
public enum DataBitsConstants {
  /**
   * <p>
   * Constants used by the DataBits property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xDATABITS_7, // 0
  /**
   * <p>
   * Constants used by the DataBits property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xDATABITS_8, // 1
}
