package com.bancolombia.myextra.libraries  ;

import com4j.*;

/**
 * <p>
 * Constants used by the FileType property
 * </p>
 */
public enum FileTypeConstants {
  /**
   * <p>
   * Constants used by the FileType property
   * </p>
   * <p>
   * The value of this constant is 0
   * </p>
   */
  xFILETYPEAUTOMATIC, // 0
  /**
   * <p>
   * Constants used by the FileType property
   * </p>
   * <p>
   * The value of this constant is 1
   * </p>
   */
  xFILETYPEBINARY, // 1
  /**
   * <p>
   * Constants used by the FileType property
   * </p>
   * <p>
   * The value of this constant is 2
   * </p>
   */
  xFILETYPETEXT, // 2
}
